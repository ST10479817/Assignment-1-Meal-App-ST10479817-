package com.example.assignment1tyricsinghst10479817

import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val txtResult = findViewById<TextView>(R.id.txtResult)
        val btnCompute = findViewById<Button>(R.id.btnCompute)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val rbGroup = findViewById<RadioGroup>(R.id.rbGroup)
        val rbBreakfast = findViewById<RadioButton>(R.id.rbEarlyMorning)
        val rbLightSnack = findViewById<RadioButton>(R.id.rbMidMorning)
        val rbLunch = findViewById<RadioButton>(R.id.rbAfternoon)
        val rbQuickBite = findViewById<RadioButton>(R.id.rbLateAfternoon)
        val rbMainCourse = findViewById<RadioButton>(R.id.rbEvening)
        val rbDessert = findViewById<RadioButton>(R.id.rbNightTime)
        val mainLayout = findViewById<ViewGroup>(R.id.main)

        mainLayout.setBackgroundResource(R.drawable.background_image)

        btnCompute.setBackgroundColor(Color.MAGENTA)
        btnClear.setBackgroundColor(Color.RED)

        btnClear.visibility = Button.GONE

        btnCompute.setOnClickListener {

            txtResult.text = "Please can you ensure that you have selected one of the options."



            if (rbBreakfast.isChecked)
            {
                txtResult.text = "Have a eggs"
                mainLayout.setBackgroundResource(R.drawable.eggs_image)
                rbGroup.visibility = Button.GONE
                btnCompute.visibility = Button.GONE
                btnClear.visibility = Button.VISIBLE
                btnCompute.visibility = Button.GONE
            }
            else if (rbLightSnack.isChecked)
            {
                txtResult.text = "Have a fruit"
                mainLayout.setBackgroundResource(R.drawable.fruit_image)
                rbGroup.visibility = Button.GONE
                btnCompute.visibility = Button.GONE
                btnClear.visibility = Button.VISIBLE
                btnCompute.visibility = Button.GONE
            }
            else if (rbLunch.isChecked)
            {
                txtResult.text = "Have a Sandwitch"
                mainLayout.setBackgroundResource(R.drawable.sandwich_image)
                rbGroup.visibility = Button.GONE
                btnCompute.visibility = Button.GONE
                btnClear.visibility = Button.VISIBLE
            }
            else if (rbQuickBite.isChecked)
            {
                txtResult.text = "Have a cake"
                mainLayout.setBackgroundResource(R.drawable.cake_image)
                rbGroup.visibility = Button.GONE
                btnCompute.visibility = Button.GONE
                btnClear.visibility = Button.VISIBLE
                btnCompute.visibility = Button.GONE
            }
            else if (rbMainCourse.isChecked)
            {
                txtResult.text = "Have a Pasta"
                mainLayout.setBackgroundResource(R.drawable.pasta_image)
                rbGroup.visibility = Button.GONE
                btnCompute.visibility = Button.GONE
                btnClear.visibility = Button.VISIBLE
                btnCompute.visibility = Button.GONE
            }
            else if (rbDessert.isChecked)
            {
                txtResult.text = "Have a Ice Cream"
                mainLayout.setBackgroundResource(R.drawable.icecream)
                rbGroup.visibility = Button.GONE
                btnCompute.visibility = Button.GONE
                btnClear.visibility = Button.VISIBLE
                btnCompute.visibility = Button.GONE
            }
        }

        btnClear.setOnClickListener {

            txtResult.text = "Please pick what time of day is it"

            rbGroup.visibility = Button.VISIBLE
            btnCompute.visibility = Button.VISIBLE
            btnClear.visibility = Button.GONE

            mainLayout.setBackgroundResource(R.drawable.background_image)

            rbGroup.clearCheck()

        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}